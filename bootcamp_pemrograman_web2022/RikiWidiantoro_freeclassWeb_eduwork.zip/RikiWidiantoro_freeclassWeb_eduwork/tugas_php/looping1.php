<?php

for( $r = 0; $r < 10; $r++ ) {
    for( $i = 0; $i < $r; $i++ ) {
        echo $i;
    }
    echo "<br>";
}

?>