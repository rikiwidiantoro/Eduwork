-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 05, 2022 at 08:25 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.0.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `nana_art`
--

-- --------------------------------------------------------

--
-- Table structure for table `gerabah`
--

CREATE TABLE `gerabah` (
  `id_gerabah` int(11) NOT NULL,
  `gambar` varchar(128) NOT NULL,
  `nama` varchar(128) NOT NULL,
  `bahan` varchar(128) NOT NULL,
  `ukuran` varchar(255) NOT NULL,
  `berat` varchar(128) NOT NULL,
  `harga_grosir` int(11) NOT NULL,
  `harga_konsumen` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `gerabah`
--

INSERT INTO `gerabah` (`id_gerabah`, `gambar`, `nama`, `bahan`, `ukuran`, `berat`, `harga_grosir`, `harga_konsumen`) VALUES
(1, 'kendil ari2.png', 'Kendil Ari-Ari', 'Tanah Liat', 'Tinggi 12cm, Diameter 12cm', '200 gr', 5000, 6000),
(2, 'kendil ari2.png', 'Kendil Ari-Ari', 'Tanah Liat', 'Tinggi 14cm, Diameter 13cm', '200 gr', 8000, 10000),
(3, 'kendil ari2.png', 'Kendil Ari-Ari', 'Tanah Liat', 'Tinggi 13cm, Diameter 14cm', '300 gr', 7000, 8000),
(4, 'kendi-teko.png', 'Kendi (Teko)', 'Tanah Liat', 'Tinggi 22cm, Diameter 17cm\r\n', '250 gr', 6000, 7500),
(5, 'kreweng-wajan.png', 'Kreweng (Wajan)\r\n', 'Tanah Liat', 'Diameter 40cm', '500 gr', 13000, 15000),
(6, 'sangkon-baki.png', 'Sangkon (Baki)', 'Tanah Liat', 'Tinggi 12cm, Diameter 35cm', '1.500 gr', 25000, 27000),
(7, 'kwali-jamu.png', 'Godokan Jamu (Kwali Jamu)', 'Tanah Liat', 'Tinggi 17cm, Diameter 16cm\r\n', '500 gr', 12000, 15000),
(8, 'blawong-lemper.png', 'Lemper (Blawong)', 'Tanah Liat', 'Diameter 30cm', '200 gr', 6000, 7000),
(9, 'jun-tingkep.png', 'Jun Tingkep', 'Tanah Liat', 'Tinggi 20cm, Diameter 12cm\r\n', '500 gr', 10000, 15000),
(10, 'pot-anggrek.png', 'Pot Anggrek', 'Tanah Liat', 'Tinggi 12cm, Diameter 11-15cm', '', 5000, 6000);

-- --------------------------------------------------------

--
-- Table structure for table `tas_anyam`
--

CREATE TABLE `tas_anyam` (
  `id_tas` int(11) NOT NULL,
  `gambar` varchar(128) NOT NULL,
  `nama` varchar(128) NOT NULL,
  `bahan` varchar(128) NOT NULL,
  `warna` varchar(128) NOT NULL,
  `ukuran` varchar(128) NOT NULL,
  `berat` varchar(128) NOT NULL,
  `harga_reseller` int(11) NOT NULL,
  `harga_konsumen` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tas_anyam`
--

INSERT INTO `tas_anyam` (`id_tas`, `gambar`, `nama`, `bahan`, `warna`, `ukuran`, `berat`, `harga_reseller`, `harga_konsumen`) VALUES
(1, 'tas petty.png', 'Tas Petty', 'Jali Premium', 'Merah, Putih, Kuning, Hijau, Gold, Pink (Sesuai pesanan)\r\n', 'S (15x11x23)cm, M (20x15x28)cm, L (25x15x28)cm', '250 gr-400 gr', 50000, 55000),
(2, 'tas jali premium.png', 'Tas Jali Premium\r\n', 'Jali Premium', 'Merah, Putih, Kuning, Hitam, Ungu (Sesuai pesanan)\r\n', 'S (11x20x23)cm, M (15x20x27)cm, L (15x25x28)cm', '300 gr-450 gr', 50000, 60000),
(3, 'tas batik.png', 'Tas Batik', 'Jali Premium', 'Gold Kombinasi Hitam, Hitam Kombinasi Gold, Gold Polos (Sesuai pesanan)\r\n', '', '300 gr-450 gr', 55000, 60000),
(4, 'tas becek motif.png', 'Tas Becek Motif', 'Embos', 'Merah, Putih, Biru, Hitam, dll', 'S (20x13x25)cm, M (23x13x27)cm, L (25x15x28)cm, XL (27x15x30)cm', '', 45000, 50000),
(5, 'tas angsul2 kaca.png', 'Tas Angsul-Angsul Kaca', 'Kaca', 'Merah, Putih, Kuning, Hitam, Hijau (Bisa Kombinasi)\r\n', 'S (11x23x15)cm, M (15x20x27)cm, L (15x25x27)cm', '100 gr-200 gr', 18000, 25000),
(6, 'tas rumbai.png', 'Tas Rumbai', 'Jali Premium', 'Hitam, Pink, Kuning, Ungu, dll', 'S (11x23x23)cm, M (15x20x25)cm, L (15x25x27)cm', '400 gr-600 gr', 60000, 65000),
(7, 'dompettangan.png', 'Dompet Tangan', 'Jali Premium', 'Kuning, Putih, Merah, Hitam, Cokat (Sesuai Pesanan)\r\n', 'S (20x15)cm, M (30x20)cm', '250 gr-350 gr', 50000, 70000);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `gerabah`
--
ALTER TABLE `gerabah`
  ADD PRIMARY KEY (`id_gerabah`);

--
-- Indexes for table `tas_anyam`
--
ALTER TABLE `tas_anyam`
  ADD PRIMARY KEY (`id_tas`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `gerabah`
--
ALTER TABLE `gerabah`
  MODIFY `id_gerabah` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `tas_anyam`
--
ALTER TABLE `tas_anyam`
  MODIFY `id_tas` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
