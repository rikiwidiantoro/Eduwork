<?php

$localhost = "localhost";
$username = "root";
$password = "";
$db_name = "db_perpus_komik";

$koneksi = mysqli_connect($localhost, $username, $password, $db_name);

?>